<?php
session_start();
require_once '../includes/DatabaseConnection.php';
require_once '../includes/DatabaseFunctions.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    exit('Access denied');
}

$title = "All Messages";
$messages = getAllMessages($pdo);

ob_start();
include '../templates/all_message.html.php';
$output = ob_get_clean();
include '../templates/admin_layout.html.php';
