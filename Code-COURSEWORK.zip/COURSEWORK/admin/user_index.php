<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'user') {
    header('Location: ../login/Notusersed.php');
    exit();
}
?>
