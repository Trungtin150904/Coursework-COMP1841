<?php
session_start();
if(isset($_POST['username']) && isset($_POST['email'], $_POST['password'])) {

    try{
        include '../includes/DatabaseConnection.php';
        include '../includes/DatabaseFunctions.php';

        insertUser($pdo, $_POST['username'], $_POST['email'], $_POST['password']);
        header('location: user.php');

    } catch(PDOException $e) {
        $title = 'An error has occured';
        $output = 'Database error: ' . $e->getMessage();
    }
} else{
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunctions.php';

    $title = 'Add a new user';
    $users = allUsers($pdo);

    ob_start();
    include '../templates/adduser.html.php';
    $output = ob_get_clean();
}
include '../templates/admin_layout.html.php';