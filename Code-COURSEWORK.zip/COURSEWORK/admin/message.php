<?php
session_start();
require_once '../includes/DatabaseConnection.php';
require_once '../includes/DatabaseFunctions.php';

try {
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    exit('Access denied');
}

    $title = "User Messages";
    $messages = getMessages($pdo);

    ob_start();
    include '../templates/message.html.php';
    $output = ob_get_clean();
} catch (PDOException $e) {
    $title = 'Database Error';
    $output = 'Error: ' . $e->getMessage();
}

include '../templates/admin_layout.html.php';
