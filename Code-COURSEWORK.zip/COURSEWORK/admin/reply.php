<?php
session_start();
require_once '../includes/DatabaseConnection.php';
require_once '../includes/DatabaseFunctions.php'; // Thêm dòng này để gọi được hàm đã tách

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    exit('Access denied');
}

$title = "Admin Reply";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message_id = $_POST['message_id'];
    $reply = $_POST['reply'];

    updateMessages($pdo, $message_id, $reply); // Gọi hàm đã tách

    header("Location: message.php"); // Quay về danh sách tin nhắn
    exit();
}
