<?php
try{
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunctions.php';
    
    deleteUser($pdo, $_POST['username']);
    header('location: user.php');
    exit();
    
} catch(PDOException $e) {
    $title = 'An error has occured';
    $output = 'Unable to connect to delete user: ' .$e->getMessage();
}
include '../templates/admin_layout.html.php';