<?php
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';
session_start();

try {
if (isset($_POST['oldname'], $_POST['name'])) {

    updateModule($pdo, $_POST['oldname'], $_POST['name']);
    header('location: module.php');
    exit();

} else {
        $module = getModule($pdo, $_GET['name']);
        $title = 'Edit Module';
        
        ob_start();
        include '../templates/editmodule.html.php';
        $output = ob_get_clean();
    }
} catch (PDOException $e) {
    $title = 'Error has occurred';
    $output = 'Error editing module: ' . $e->getMessage();
}
include '../templates/admin_layout.html.php';?>