<?php
session_start();
if(isset($_POST['questiontext'])) {
    try{
        include '../includes/DatabaseConnection.php';
        include '../includes/DatabaseFunctions.php';

        $imageName = '';
        if (isset($_FILES['fileToUpload']) && $_FILES['fileToUpload']['error'] == UPLOAD_ERR_OK) {
            $imageName = basename($_FILES['fileToUpload']['name']);
            $targetDir = '../uploads/';
            $targetFile = $targetDir . $imageName;
            move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $targetFile);
        }

        insertQuestion($pdo, $_POST['questiontext'], $imageName,
        $_POST['users'], $_POST['modules']);
        include '../includes/UploadFile.php';
        header('location: questions.php');

    } catch(PDOException $e) {
        $title = 'An error has occured';
        $output = 'Database error: ' . $e->getMessage();
    } 
} else{
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunctions.php';

    $title = 'Add a new question';
    $users = allUsers($pdo);
    $modules = allModules($pdo);

    ob_start();
    include '../templates/addquestion.html.php';
    $output = ob_get_clean();
}
include '../templates/admin_layout.html.php';