<?php
session_start();
require "../login/Check.php";

if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login/Login.html');
    exit();
}

$title = 'Questions Database';
ob_start();
include '../public templates/home.html.php';
$output = ob_get_clean();
include '../templates/admin_layout.html.php';
