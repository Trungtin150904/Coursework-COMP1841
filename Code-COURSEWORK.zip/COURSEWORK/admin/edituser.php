<?php
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';
session_start();

try{
if (isset($_POST['oldusername'], $_POST['username'], $_POST['email'])) {
    
    updateUser($pdo, $_POST['oldusername'], $_POST['username'], $_POST['email']);
    header('location: user.php');
    exit();

} else {
        $user = getUser($pdo, $_GET['username']);
        $title = 'Edit User';
        
        ob_start();
        include '../templates/edituser.html.php';
        $output = ob_get_clean();
    }
} catch (PDOException $e) {
    $title = 'Error has occurred';
    $output = 'Error editing user: ' . $e->getMessage();
}
include '../templates/admin_layout.html.php';?>