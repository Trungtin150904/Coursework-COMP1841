<?php
try{
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunctions.php';
    
    deleteModule($pdo, $_POST['name']);
    header('location: module.php');
    exit();
    
} catch(PDOException $e) {
    $title = 'An error has occured';
    $output = 'Unable to connect to delete module: ' .$e->getMessage();
}
include '../templates/admin_layout.html.php';