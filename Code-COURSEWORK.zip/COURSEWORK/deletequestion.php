<?php
session_start();
try{
    include 'includes/DatabaseConnection.php';
    include 'includes/DatabaseFunctions.php';


$question = getQuestion($pdo, $_POST['id']);

    if ($question && $question['user_id'] == $_SESSION['user_id']) {
        
        if (!empty($question['image'])) {
            $oldImagePath = __DIR__ . '/uploads/' . $question['image'];
            if (file_exists($oldImagePath)) {
                unlink($oldImagePath);
            }
        }

        deleteQuestion($pdo, $_POST['id']);
        
        header('location: questions.php');
        exit();
    } else {
        $title = 'Access Denied';
        $output = 'You do not have permission to delete this question.';
    }    
} catch(PDOException $e) {
    $title = 'An error has occured';
    $output = 'Unable to connect to delete question: ' .$e->getMessage();
} 
include 'public templates/layout.html.php';