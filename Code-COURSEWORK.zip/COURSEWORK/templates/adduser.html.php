<form action="" method="post">
    <label for="username">Add your username:</label>
    <input type="text" name="username" required><br><br>

    <label for="email">Add your email:</label>
    <input type="email" name="email" required><br><br>

    <label for='password'>Password:</label>
    <input type="password" name="password" required>

    <input type="submit" name="submit" value="Add User">
</form>
