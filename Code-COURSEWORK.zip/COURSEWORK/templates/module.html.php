<p><?=$totalModules?> module have been submitted to the Questions Database. </p>


<?php if(isset($error)): ?>
  <p> <?=$error ?></p>
<?php else:

 foreach ($modules as $module): ?>
    <blockquote>
        <?= htmlspecialchars($module['name'], ENT_QUOTES, 'UTF-8') ?>

        <a href="editmodule.php?name=<?=htmlspecialchars($module['name']) ?>">Edit</a>

    <form action="deletemodule.php" method="post">
        <input type="hidden" name="name" value="<?=$module['name']?>">
    <input type="submit" value="Delete">
  </form>

 </blockquote>
<?php endforeach; 
        endif; ?>