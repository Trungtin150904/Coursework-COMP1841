<form action="" method="post">
    <input type="hidden" name="oldname" value="<?= htmlspecialchars($module['name']) ?>">
    <input type="hidden" name="name" value="<?= htmlspecialchars($module['name']) ?>">
    <label for='oldname'>Edit your module here:</label>
    <textarea name="name" rows="3" cols="40"><?= htmlspecialchars($module['name']) ?></textarea>
    <input type="submit" name="submit" value="Save">
</form>