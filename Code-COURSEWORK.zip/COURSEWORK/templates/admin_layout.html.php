<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="/COMP1841/COURSEWORK/questions.css">
    <title><?=$title?></title>
</head>
<body>
    <header id="admin">
        <h1>Admin Area</h1>
    </header>
    <nav>
        <ul>
            <li><a href="/COMP1841/COURSEWORK/admin/questions.php">Questions</a></li>
            <li><a href="/COMP1841/COURSEWORK/admin/addquestion.php">Add a new question</a></li>
            <li><a href="/COMP1841/COURSEWORK/admin/user.php">Users</a></li>
            <li><a href="/COMP1841/COURSEWORK/admin/adduser.php">Add user</a></li>
            <li><a href="/COMP1841/COURSEWORK/admin/module.php">Module</a></li>
            <li><a href="/COMP1841/COURSEWORK/admin/addmodule.php">Add module</a></li>
            <li><a href="/COMP1841/COURSEWORK/admin/message.php">Message</a></li>
            <li><a href="/COMP1841/COURSEWORK/admin/all_message.php">All Messages</a></li>
            <li><a href="/COMP1841/COURSEWORK/admin/Logout.php">Logout</a></li>
        </ul>
    </nav>
    <main>
        <p><?= $output ?? '' ?></p>
    </main>
    <footer>&copy; IJDB 2025</footer>
</body>
</html>