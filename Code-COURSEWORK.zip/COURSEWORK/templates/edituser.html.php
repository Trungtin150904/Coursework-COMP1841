<form action="" method="post">
    <input type="hidden" name="username" value="<?=$question['username'];?>">
    <input type="hidden" name="oldusername" value="<?=$user['username']?>">
    <label for='oldusername'>Edit your question here:</label>
    <textarea name="username" rows="3" cols="40"><?=$user['username']?></textarea>

    <label for="email">Email:</label>
    <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
    <input type="submit" name="submit" value="Save">
</form>


