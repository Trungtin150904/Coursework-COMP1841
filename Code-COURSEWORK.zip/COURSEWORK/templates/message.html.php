<h2>Messages from Users</h2>

<?php if (empty($messages)): ?>
    <p>No messages to display.</p>
<?php endif; ?>

<?php foreach($messages as $msg): ?>
    <div class="message-box">
        <strong>From:</strong> <?= htmlspecialchars($msg['sender_id']) ?><br>
        <strong>To:</strong> <?= htmlspecialchars($msg['receiver_id']) ?><br>
        <strong>Sent at:</strong> <?= htmlspecialchars($msg['sent_at']) ?><br>
        <strong>Message:</strong> <?= htmlspecialchars($msg['message']) ?>

        <form action="reply.php" method="post" class="reply-form">
            <input type="hidden" name="message_id" value="<?= $msg['id'] ?>">
            <label for="reply">Reply:</label>
            <textarea name="reply" rows="5" cols="50"><?= htmlspecialchars($msg['reply'] ?? '') ?></textarea><br>
            <input type="submit" value="Send Reply">
        </form>
    </div>
<?php endforeach; ?>
