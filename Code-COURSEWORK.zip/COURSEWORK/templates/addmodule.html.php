<form action="" method="post">
    <label for='name'>Add your module here:</label>
    <textarea name="name" rows="3" cols="40"></textarea>    
    <input type="submit" name="submit" value="Add">
</form>