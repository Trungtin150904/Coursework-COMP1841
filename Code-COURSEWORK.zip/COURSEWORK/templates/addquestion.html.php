
<form action="addquestion.php" method="post" enctype="multipart/form-data">
    <label for='questiontext'>Type your question here:</label>
    <textarea name="questiontext" rows="3" cols="40"></textarea>
    

    <select name="users">
        <option value="">select an user</option>
        <?php foreach ($users as $user):?>
            <option value="<?=htmlspecialchars($user['id'], ENT_QUOTES, 'UTF-8'); ?>">
                <?=htmlspecialchars($user['username'], ENT_QUOTES, 'UTF-8'); ?>
            </option>
        <?php endforeach;?>
    </select>

    <select name="modules">
        <option value="">select a module</option>
        <?php foreach ($modules as $module): ?>
            <option value="<?= htmlspecialchars($module['id'], ENT_QUOTES, 'UTF-8'); ?>">
                <?= htmlspecialchars($module['name'], ENT_QUOTES, 'UTF-8'); ?>
            </option>
        <?php endforeach; ?>
    </select>
    <br />
    <label for="fileToUpload">Select image to upload:</label>
    <input type="file" name="fileToUpload" id="fileToUpload" /> <?= isset($_POST['fileToUpload']) ? $_POST['fileToUpload'] : '' ?>

    <input type="submit" name="submit" value="Add">
</form>