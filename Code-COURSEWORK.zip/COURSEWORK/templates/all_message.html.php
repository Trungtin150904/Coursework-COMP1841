<h2>All Replied Messages</h2>

<?php if (empty($messages)): ?>
    <p>No replied messages found.</p>
<?php else: ?>
    <?php foreach ($messages as $msg): ?>
        <div class="message-box">
            <p><strong>From:</strong> <?= htmlspecialchars($msg['sender_id']) ?></p>
            <p><strong>To:</strong> <?= htmlspecialchars($msg['receiver_id']) ?></p>
            <p><strong>Sent at:</strong> <?= htmlspecialchars($msg['sent_at']) ?></p>
            <p><strong>Message:</strong><br> <?= nl2br(htmlspecialchars($msg['message'])) ?></p>
            <p><strong>Admin Reply:</strong><br> <?= nl2br(htmlspecialchars($msg['reply'])) ?></p>
        </div>
    <?php endforeach; ?>
<?php endif; ?>
