<p><?=$totalUsers?> users have been submitted to the Questions Database. </p>

<?php if(isset($error)): ?>
  <p> <?=$error ?></p>
<?php else:

 foreach ($users as $user): ?>
 <blockquote>
      <?= htmlspecialchars($user['username'], ENT_QUOTES, 'UTF-8') ?>
      <br />Email: <a href="mailto:<?=htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8');?>">
            <?=htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8'); ?></a><br /> 

      <a href="edituser.php?username=<?= htmlspecialchars($user['username']) ?>">Edit</a>

  <form action="deleteuser.php" method="post">
      <input type="hidden" name="username" value="<?=$user['username']?>">
      <input type="submit" value="Delete">
  </form>

 </blockquote>
<?php endforeach;
          endif; ?>