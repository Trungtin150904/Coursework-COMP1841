<p><?=$totalQuestions?> questions have been submitted to the Questions Database. </p>

<?php    foreach($questions as $question): ?>
        <blockquote>
            <img width="200px" height="200px" src="../uploads/<?=htmlspecialchars($question['image'], ENT_QUOTES, 'UTF-8'); ?>">
            <br />Question: <?=htmlspecialchars($question['questiontext'], ENT_QUOTES, 'UTF-8')?>
            <br />Module Name: <?=htmlspecialchars($question['name'], ENT_QUOTES, 'UTF-8')?>
            
            <br />Submitted on <?=htmlspecialchars(date("D d M y", strtotime($question['questiondate'])), ENT_QUOTES, 'UTF-8')?>            
            
            (by <a href="mailto:<?=htmlspecialchars($question['email'], ENT_QUOTES, 'UTF-8');?>">
                <?=htmlspecialchars($question['username'], ENT_QUOTES, 'UTF-8'); ?></a>)

        <a href="editquestion.php?id=<?=$question['id']?>">Edit</a>

        <form action="deletequestion.php" method="post">
                <input type="hidden" name="id" value="<?=$question['id']?>">
                <input type="submit" value="Delete">
        </form> 
        </blockquote>
        <?php endforeach;
 ?>
