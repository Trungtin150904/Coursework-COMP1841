<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Not Logged In</title>
  <link rel="stylesheet" href="Login.css" />
</head>
<body>
  <div class="message-container">
    <h2>⚠️ Access Denied</h2>
    <p>You are not logged in. This login page is for admins only. Please use the correct login page. <a href="Login.html">login here</a>.</p>
  </div>
</body>
</html>
