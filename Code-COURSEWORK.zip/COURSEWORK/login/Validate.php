<?php
session_start();
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php'; 

$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

try {
    $stmt = $pdo->prepare('SELECT * FROM user WHERE email = :email AND role IN ("admin", "user")');
    $stmt->execute([':email' => $email]);
    $user = $stmt->fetch();

if ($user) {
        // Kiểm tra mật khẩu
        if ($password === $user['password']){
 
            $_SESSION['loggedin'] = true;
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];

            // Điều hướng tùy theo vai trò
            if ($user['role'] === 'admin') {
                header('Location: ../admin/index.php');
            } else {
                header('Location: ../index.php');
            }
            exit();
        } else {
            // Sai mật khẩu
            header('Location: Wrongpassword.php');
            exit();
        }
    } else {
        // Không tồn tại email
        header('Location: Notadmin.php');
        exit();
    }
} catch (PDOException $e) {
    echo 'Database error: ' . $e->getMessage();
}
