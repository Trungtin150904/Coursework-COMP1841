<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Access Denied</title>
  <link rel="stylesheet" href="Login.css" />
</head>
<body>
  <div class="message-container">
    <h2>⚠️ Access Denied</h2>
    <p>This login page is only for <strong>users</strong>. Please use the correct login page.</p>
    <a href="user_login.html">Go back</a>
  </div>
</body>
</html>
