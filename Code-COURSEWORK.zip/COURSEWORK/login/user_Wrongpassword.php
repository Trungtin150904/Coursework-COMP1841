<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Wrong Password</title>
    <link rel="stylesheet" href="Login.css"> 
</head>
<body>
    <div class="message-container">
    <h2>❌ Incorrect Password!</h2>
    <p>Please try again with the correct password.</p>
    <a href="user_login.html">Back to login</a>
    </div>
</body>
</html>
