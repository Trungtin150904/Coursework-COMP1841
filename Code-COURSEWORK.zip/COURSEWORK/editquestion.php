<?php
session_start();
include 'includes/DatabaseConnection.php';
include 'includes/DatabaseFunctions.php';

try {
    if (isset($_POST['questiontext'])) {
        $questionId = $_POST['questionid'];
        $questionText = $_POST['questiontext'];

        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $oldQuestion = getQuestion($pdo, $questionId);
            $oldImage = $oldQuestion['image'];

            
            $uploadDir = __DIR__ . '/uploads/';
            $fileName = basename($_FILES['image']['name']);
            $targetPath = $uploadDir . $fileName;

            $oldImagePath = __DIR__ . '/uploads/' . $oldImage;
            if (!empty($oldImage) && file_exists($oldImagePath)) {
                unlink($oldImagePath);
            }

            move_uploaded_file($_FILES['image']['tmp_name'], $targetPath);

            updateQuestionImage($pdo, $questionId, $questionText, $fileName);
        } else {
            updateQuestion($pdo, $questionId, $questionText);
        }

        header('location: questions.php');
        exit;
    } else {
        $question = getQuestion($pdo, $_GET['id']);

        if ($_SESSION['user_id'] != $question['user_id']) {
            echo 'You do not have permission to edit this question.';
            exit;
        }
        
        $title = 'Edit question';
        
        ob_start();
        include 'public templates/editquestion.html.php';
        $output = ob_get_clean();
    }
} catch (PDOException $e) {
    $title = 'Error has occurred';
    $output = 'Error editing question: ' . $e->getMessage();
}

include 'public templates/layout.html.php';
?>
