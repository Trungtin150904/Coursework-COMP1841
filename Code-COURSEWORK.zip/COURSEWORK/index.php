<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'user') {
    header('Location: login/user_Login.html'); 
    exit();
}

$title = 'Questions Database';

ob_start();
include 'public templates/home.html.php'; 
$output = ob_get_clean();

include 'public templates/layout.html.php';
