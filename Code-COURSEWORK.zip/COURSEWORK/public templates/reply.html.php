<h2>Replies from Admin</h2>

<?php if (empty($replies)): ?>
    <p>No replies yet.</p>
<?php else: ?>
    <?php foreach ($replies as $reply): ?>
        <div>
            <label>Your message:</label>
            <label><?= htmlspecialchars($reply['message']) ?></label>
            <br>
            <label><strong>Admin's reply:</strong></label>
            <label><?= htmlspecialchars($reply['reply']) ?></label>
            <br><hr><br>
        </div>
    <?php endforeach; ?>
<?php endif; ?>
