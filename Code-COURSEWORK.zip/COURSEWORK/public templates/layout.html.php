<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="questions.css">
    <title><?=$title?></title>
</head>
<body>
    <header><h1>Questions Database</h1></header>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="questions.php">Questions List</a></li>
            <li><a href="addquestion.php">Add a new question</a></li>
            <li><a href="contact.php">Contact Us</a></li>
            <li><a href="view_reply.php">View Replies</a></li>
            <li><a href="/COMP1841/COURSEWORK/Logout.php">Logout</a></li>
        </ul>
    </nav>
    <main>
        <?=$output?>
    </main>
    <footer>&copy; IJDB 2025</footer>
</body>
</html>