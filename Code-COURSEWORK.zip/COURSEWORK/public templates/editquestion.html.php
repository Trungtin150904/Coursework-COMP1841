<form action="" method="post" enctype="multipart/form-data">
    <input type="hidden" name="questionid" value="<?=$question['id'];?>">
    <label for='questiontext'>Edit your question here:</label>
    
    <textarea name="questiontext" rows="3" cols="40">
    <?=htmlspecialchars($question['questiontext'])?></textarea>

    <?php if (!empty($question['image'])): ?>
    <p>Current image:</p>
    <img src="/COMP1841/COURSEWORK/uploads/<?= htmlspecialchars($question['image']) ?>" width="200"><br><br>
    <?php endif; ?>

    <label for="image">Edit image (optional):</label>
    <input type="file" name="image"><br><br>

    <input type="submit" name="submit" value="Save">
</form>
