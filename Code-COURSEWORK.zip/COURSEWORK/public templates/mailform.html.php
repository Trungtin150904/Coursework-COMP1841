<form action="contact.php" method="post">
    <label for="message">Message:</label>
    <textarea name="message" rows="8" cols="60" required></textarea><br><br>
    <input type="submit" value="Send email">
</form>
