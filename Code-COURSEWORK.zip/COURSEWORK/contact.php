<?php
session_start();
require_once 'includes/DatabaseConnection.php';
require_once 'includes/DatabaseFunctions.php';

$title = "Contact Us";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['message'])) {
    $message = $_POST['message'];

    $sender_id = $_SESSION['user_id'];   // ID của người dùng đang đăng nhập
    $receiver_id = 1;                    // Ví dụ: admin có id = 1 trong bảng `user`

    sendMessage($pdo, $sender_id, $receiver_id, $message);


    $output = "<p>Message sent successfully. Please wait for admin's response.</p>";
} else {
    ob_start();
    include 'public templates/mailform.html.php';
    $output = ob_get_clean();
}

include 'public templates/layout.html.php';
