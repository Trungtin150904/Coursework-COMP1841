<?php
session_start();
require_once 'includes/DatabaseConnection.php';
require_once 'includes/DatabaseFunctions.php';

$title = "Admin Reply";

// Kiểm tra người dùng đã đăng nhập chưa
if (!isset($_SESSION['user_id'])) {
    exit('Access denied');
}

$sender_id = $_SESSION['user_id'];


// Gọi function tách riêng ra
$replies = getReplyFromAdmin($pdo, $sender_id);

// Hiển thị giao diện
ob_start();
include 'public templates/reply.html.php';
$output = ob_get_clean();

include 'public templates/layout.html.php';
