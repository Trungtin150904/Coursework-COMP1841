<?php

function query($pdo, $sql, $parameters = []) {
    $query = $pdo->prepare($sql);
    $query->execute($parameters);
    return $query;
}

function totalQuestions($pdo) {
    $query = query($pdo, 'SELECT COUNT(*) FROM question');
    $row = $query->fetch();
    return $row[0];
}

function totalUsers($pdo) {
    $query = query($pdo, 'SELECT COUNT(*) FROM user');
    $row = $query->fetch();
    return $row[0];
}

function totalModules($pdo) {
    $query = query($pdo, 'SELECT COUNT(*) FROM module');
    $row = $query->fetch();
    return $row[0];
}

function getQuestion($pdo, $id) {
    $parameters = [':id' => $id];
    $query = query($pdo, 'SELECT * FROM question WHERE id = :id', $parameters);
    return $query->fetch();
}

function getUser($pdo, $username) {
    $parameters = [':username' => $username];
    $query = query($pdo, 'SELECT * FROM user WHERE username = :username', $parameters);
    return $query->fetch();
}

function getModule($pdo, $name) {
    $parameters = [':name' => $name];
    $query = query($pdo, 'SELECT * FROM module WHERE name = :name', $parameters);
    return $query->fetch();
}

function updateQuestion($pdo, $questionid, $questiontext) {
    $query = 'UPDATE question SET questiontext = :questiontext WHERE id = :id';
    $parameters = [':questiontext' => $questiontext, ':id' => $questionid];
    query($pdo, $query, $parameters);
}

function updateQuestionImage($pdo, $questionid, $questiontext, $filename) {
    $query = 'UPDATE question SET questiontext = :questiontext, image = :image WHERE id = :id';
    $parameters = [
        ':questiontext' => $questiontext,
        ':image' => $filename,
        ':id' => $questionid
    ];
    query($pdo, $query, $parameters);
}


function updateUser($pdo, $oldusername, $username, $email) {
    $query = 'UPDATE user SET username = :username, email = :email WHERE username = :oldusername';
    $parameters = [':username' => $username, ':oldusername' => $oldusername, ':email' => $email];
    query($pdo, $query, $parameters);
}

function updateModule($pdo, $oldname, $name) {
    $query = 'UPDATE module SET name = :name WHERE name = :oldname';
    $parameters = [':name' => $name, ':oldname' => $oldname];
    query($pdo, $query, $parameters);
}

function deleteQuestion($pdo, $id) {
    $question = getQuestion($pdo, $id);
    $image = $question['image'];

    if (!empty($image)) {
        $filePath = '../uploads/' . $image;
        if (file_exists($filePath)) {
            unlink($filePath);
        }
    }

    $query = 'DELETE FROM question WHERE id = :id';
    $parameters = [':id' => $id];
    query($pdo, $query, $parameters);
}

function deleteUser($pdo, $username) {
    $query = 'DELETE FROM user WHERE username = :username';
    $parameters = [':username' => $username];
    query($pdo, $query, $parameters);
}

function deleteModule($pdo, $name) {
    $query = 'DELETE FROM module WHERE name = :name';
    $parameters = [':name' => $name];
    query($pdo, $query, $parameters);
}

function insertQuestion($pdo, $questiontext, $fileToUpload, $userId, $modules) {
    $query = 'INSERT INTO question (questiontext, questiondate, `image`, user_id, module_id)
              VALUES (:questiontext, CURDATE(), :fileToUpload, :user_id, :module_id)';
    $parameters = [
        ':questiontext' => $questiontext,
        ':fileToUpload' => $fileToUpload,
        ':user_id' => $userId,
        ':module_id' => $modules
    ];
    query($pdo, $query, $parameters);
}


function insertUser($pdo, $username, $email, $password) {
    $query = 'INSERT INTO user (username, email, password) VALUES (:username, :email, :password)';
    $parameters = [':username' => $username, ':email' => $email, ':password' => $password];
    query($pdo, $query, $parameters);
}

function insertModule($pdo, $name) {
    $query = 'INSERT INTO module (name) VALUES (:name)';
    $parameters = [':name' => $name];
    query($pdo, $query, $parameters);
}

function allUsers($pdo) {
    $users = query($pdo, 'SELECT * FROM user');
    return $users->fetchAll();
}

function allModules($pdo) {
    $modules = query($pdo, 'SELECT * FROM module');
    return $modules->fetchAll();
}

function allQuestions($pdo) {
    $questions = query($pdo, 'SELECT question.id, questiontext, `image`, questiondate, username, module.name, email FROM question
    INNER JOIN user ON user_id = user.id
    INNER JOIN module ON module_id = module.id');
    return $questions->fetchAll();
}

function getMessages($pdo) {
    $messages = query($pdo, "SELECT * FROM messages WHERE reply IS NULL OR reply = '' ORDER BY sent_at DESC");
    return $messages->fetchAll();
}


function getAllMessages($pdo) {
    $messages = query($pdo,'SELECT * FROM messages WHERE reply IS NOT NULL ORDER BY sent_at DESC');
    return $messages->fetchAll();
}


function updateMessages($pdo, $message_id, $reply) {
    $query = "UPDATE messages SET reply = :reply WHERE id = :id";
    $parameters = [
        ':reply' => $reply,
        ':id' => $message_id
    ];
    query($pdo, $query, $parameters);
}

function sendMessage($pdo, $sender_id, $receiver_id, $message) {
    $query = 'INSERT INTO messages (sender_id, receiver_id, message) 
              VALUES (:sender_id, :receiver_id, :message)';
    $parameters = [
        ':sender_id' => $sender_id,
        ':receiver_id' => $receiver_id,
        ':message' => $message
    ];
    query($pdo, $query, $parameters);
}

function getReplyFromAdmin($pdo, $sender_id) {
    $stmt = $pdo->prepare('SELECT id, message, reply FROM messages WHERE sender_id = :sender_id AND reply IS NOT NULL');
    $stmt->execute(['sender_id' => $sender_id]);
    return $stmt->fetchAll();
}


