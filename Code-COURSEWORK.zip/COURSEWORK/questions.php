<?php 
session_start();
require "login/Check.php";
try {
    include 'includes/DatabaseConnection.php';
    include 'includes/DatabaseFunctions.php';
    
    $questions = allQuestions($pdo);
    $title = 'Question List';
    $totalQuestions = totalQuestions($pdo);

    ob_start();
    include 'public templates/questions.html.php';
    $output = ob_get_clean();

} catch(PDOException $e) {
    $title = 'An error has occured';
    $output = 'Database error: ' . $e->getMessage();
    
      ob_start();
    include 'public templates/questions.html.php';  
    $output = ob_get_clean();
 }
include 'public templates/layout.html.php';